import hlt.*;

import java.util.*;

public class MyBot {

    public static void main(final String[] args) {

        final Networking networking = new Networking();
        final GameMap gameMap = networking.initialize("Tamagocchi");

        // We now have 1 full minute to analyse the initial map.
        final String initialMapIntelligence =
                "width: " + gameMap.getWidth() +
                "; height: " + gameMap.getHeight() +
                "; players: " + gameMap.getAllPlayers().size() +
                "; planets: " + gameMap.getAllPlanets().size();

        Log.log(initialMapIntelligence);

        final ArrayList<Move> moveList = new ArrayList<>();

        final int myPlayerId = gameMap.getMyPlayerId();

        for (;;) {
            moveList.clear();
            networking.updateMap(gameMap);

            for (final Ship ship : gameMap.getMyPlayer().getShips().values()) {

                boolean shipCommandIssued = false;

                Log.log("++++ Iterating on SHIP [" + ship.getId() + "]");

                // Bypass if ship is docked.
                if (ship.getDockingStatus() != Ship.DockingStatus.Undocked) {
                    Log.log("Ship " + ship.getId() + " is DOCKED, bypassing!");
                    continue;
                }

                Log.log("Ship " + ship.getId() + " is not docked (" + ship.getDockingStatus() + "), continuing!");


                // Find nearby objects. Double (key) = distance to, Entity = nearby entity
                Map<Double,Ship> myNearbyShips = new TreeMap<>();
                Map<Double,Ship> enemyNearbyShips = new TreeMap<>();
                Map<Double,Planet> nearbyOwnedPlanets = new TreeMap<>();
                Map<Double,Planet> nearbyUnownedPlanets = new TreeMap<>();
                Map<Double,Planet> nearbyEnemyOwnedPlanets = new TreeMap<>();

                // TODO: Maybe refactor to get ALL planets, then ships, then classify.
                for (Map.Entry<Double,Entity> entry : gameMap.nearbyEntitiesByDistance(ship).entrySet()) {
                    if (entry.getValue() instanceof Ship) {
                        if (entry.getValue().equals(ship)) { continue; } // Skip ship currently focused
                        if (entry.getValue().getOwner() == ship.getOwner()) {
                            myNearbyShips.put(entry.getKey(), (Ship) entry.getValue());
                        } else {
                            enemyNearbyShips.put(entry.getKey(), (Ship) entry.getValue());
                        }

                    }
                    if (entry.getValue() instanceof Planet) {
                        Planet thisPlanet = (Planet) entry.getValue();
                        if (thisPlanet.isOwned()) {
                            if (thisPlanet.getOwner() == myPlayerId) {
                                nearbyOwnedPlanets.put(entry.getKey(), (Planet) entry.getValue());
                            } else {
                                nearbyEnemyOwnedPlanets.put(entry.getKey(), (Planet) entry.getValue());
                            }
                        } else {
                            nearbyUnownedPlanets.put(entry.getKey(), (Planet) entry.getValue());
                        }
                    }
                }

                for (Map.Entry<Double,Ship> nearbyShipEntry : myNearbyShips.entrySet()) {
                    // Log.log("My nearby ship, distance: " + nearbyShipEntry.getKey() + ", entity: " + nearbyShipEntry.getValue().toString());
                }
                for (Map.Entry<Double,Ship> nearbyShipEntry : enemyNearbyShips.entrySet()) {
                    // Log.log("ENEMY nearby ship, distance: " + nearbyShipEntry.getKey() + ", entity: " + nearbyShipEntry.getValue().toString());
                }

                for (Map.Entry<Double,Planet> nearbyPlanetEntry : nearbyOwnedPlanets.entrySet()) {
                    // Log.log("Nearby planets, distance: " + nearbyPlanetEntry.getKey() + ", entity: " + nearbyPlanetEntry.getValue().toString());
                }


                // Phase 1: Iterate nearby unowned planets.
                for (Map.Entry<Double,Planet> nearbyUnownedPlanetEntry : nearbyUnownedPlanets.entrySet()) {

                    Planet planet = nearbyUnownedPlanetEntry.getValue();

                    if (planet.isOwned()) {
                        continue;
                    }

                    if (ship.canDock(planet)) {
                        moveList.add(new DockMove(ship, planet));
                        Log.log("Ship " + ship.getId() + "/" + ship.getOwner() + " DOCKING on unowned Planet " + planet.toString());
                        shipCommandIssued = true;
                        break;
                    }

                    final ThrustMove newThrustMove = Navigation.navigateShipToDock(gameMap, ship, planet, Constants.MAX_SPEED);
                    if (newThrustMove != null) {
                        moveList.add(newThrustMove);
                        Log.log("Ship " + ship.getId() + "/" + ship.getOwner() + " THRUSTING for unowned Planet " + planet.toString());
                        shipCommandIssued = true;
                    }

                    break;
                }

                // If move already issued, exit block.
                if (shipCommandIssued) {
                    Log.log("Ship " + ship.getId() + " move has been issued, bypassing search for enemy ships: " + moveList.get(0).getType().toString());
                    continue;
                } else {
                    Log.log("No ship commands issued, searching for enemy ships.");
                }

                boolean thrustingForEnemyShip = false;

                // Begin searching for enemy ships to eliminate.
                Map<Double,Ship> allEnemyShips = new TreeMap<>();
                for (Ship theShip : gameMap.getAllShips()) {
                    if (theShip.getOwner() != myPlayerId) {
                        Position enemyShipPosition = new Position(theShip.getXPos(), theShip.getYPos());
                        Position myPosition = new Position(ship.getXPos(), ship.getYPos());
                        Double distance = myPosition.getDistanceTo(enemyShipPosition);
                        allEnemyShips.put(distance, theShip);
                    }
                }

                Log.log("Found " + allEnemyShips.size() + " enemy ships.");

                for (Map.Entry<Double,Ship> enemyShipEntry : allEnemyShips.entrySet()) {
                    Log.log("Found enemy ship at distance [" + enemyShipEntry.getKey() + "]: " + enemyShipEntry.getValue());
                }

                for (Map.Entry<Double,Ship> nearbyEnemyShipEntry : allEnemyShips.entrySet()) {

                    if (thrustingForEnemyShip) { continue; }

                    Ship enemyShip = nearbyEnemyShipEntry.getValue();

                    Position enemyShipPosition = new Position(enemyShip.getXPos(), enemyShip.getYPos());

                    final ThrustMove thrustTowardEnemyShipMove = Navigation.navigateShipTowardsTarget(
                            gameMap, ship, enemyShipPosition, Constants.MAX_SPEED, true,
                            Constants.MAX_NAVIGATION_CORRECTIONS, Math.PI / 365.0);
                    if (thrustTowardEnemyShipMove != null) {
                        Log.log("Adding move to moveList: " + thrustTowardEnemyShipMove.toString());
                        moveList.add(thrustTowardEnemyShipMove);
                        thrustingForEnemyShip = true;
                        shipCommandIssued = true;
                    } else {
                        Log.log("Could not thrust toward enemy ship for some damn reason!");
                    }

                }

                /*
                // Phase 2: Iterate nearby enemy planets.
                for (Map.Entry<Double,Planet> nearbyEnemyOwnedPlanetEntry : nearbyEnemyOwnedPlanets.entrySet()) {

                    if (thrustingForEnemyShip) { continue; }

                    Planet enemyPlanet = nearbyEnemyOwnedPlanetEntry.getValue();

                    List<Integer> dockedEnemyShips = enemyPlanet.getDockedShips();

                    for (Integer enemyShipId : dockedEnemyShips) {

                        if (thrustingForEnemyShip) { continue; }

                        final Ship enemyShip = gameMap.getShip(enemyPlanet.getOwner(), enemyShipId);
                        Log.log("Found ENEMY ship docked on Planet " + enemyPlanet.getId() + ": " + enemyShip.toString() + ", headed to intercept!");

                        Position enemyShipPosition = new Position(enemyShip.getXPos(), enemyShip.getYPos());

                        final ThrustMove thrustTowardEnemyShipMove = Navigation.navigateShipTowardsTarget(
                                gameMap, ship, enemyShipPosition, Constants.MAX_SPEED / 2, true,
                                Constants.MAX_NAVIGATION_CORRECTIONS, Math.PI / 180.0);
                        if (thrustTowardEnemyShipMove != null) {
                            Log.log("Adding move to moveList: " + thrustTowardEnemyShipMove.toString());
                            moveList.add(thrustTowardEnemyShipMove);
                            thrustingForEnemyShip = true;
                        }
                    }
                }
                */


                if (!shipCommandIssued) {
                    Log.log("Ship is doing jack shit: " + ship.getId());
                }

            }

            Networking.sendMoves(moveList);
        }
    }
}
